%clear;clc;

fid1 = fopen('./compute_reproject_pro_corner1.txt');
fid2 = fopen('./compute_reproject_pro_corner2.txt');

Corner_num = 99;

sizeA = [2 Inf];
sizeB = [2 Inf];

A = fscanf(fid1, '%f%f', sizeA);

B = fscanf(fid2, '%f%f', sizeB);

E = A - B;

%%%% blob
fid1 = fopen('../Blob_detect/compute_reproject_pro_corner1.txt');
fid2 = fopen('../Blob_detect/compute_reproject_pro_corner2.txt');


sizeA1 = [2 Inf];
sizeB1 = [2 Inf];

A1 = fscanf(fid1, '%f%f', sizeA1);

B1 = fscanf(fid2, '%f%f', sizeB1);

E2 = A1 - B1;

%%%% blob
fid1 = fopen('../Circle_Fitting/compute_reproject_pro_corner1.txt');
fid2 = fopen('../Circle_Fitting/compute_reproject_pro_corner2.txt');


sizeA2 = [2 Inf];
sizeB2 = [2 Inf];

A2 = fscanf(fid1, '%f%f', sizeA2);

B2 = fscanf(fid2, '%f%f', sizeB2);

E3 = A2 - B2;

AA = size(E);

N = AA(2) / Corner_num;

figure;
for i = 1:N 
    
    %scatter(E(1,(i-1)*Corner_num + 1: i*Corner_num), E(2,(i-1)*Corner_num + 1: i*Corner_num), 10, '+');
    plot(E(1,(i-1)*Corner_num + 1: i*Corner_num), E(2,(i-1)*Corner_num + 1: i*Corner_num), '+');
    hold on;
    
end



xlabel('\Deltav');
ylabel('\Deltau');
title('Reprojection error / pixel');

set(gca, 'XTick', -1:0.2:1);
set(gca, 'YTick', -1:0.2:1);
axis([-1 1 -1 1]);

A1 = max(E(1,:));
A2 = max(E(2,:));

figure;
hist(E2(1,:),200,'facecolor','r'); ylim([0 20]); xlim([-0.3 0.3]);hold on;
hist(E3(1,:),200,'facecolor','b');  ylim([0 20]); xlim([-0.3 0.3]);hold on;
h = findobj(gca, 'Type','patch');
set(h(1), 'FaceColor','b', 'EdgeColor','w')
set(h(2), 'FaceColor','r', 'EdgeColor','w')

legend({'P2P method','our proposed method'});

F1 = 0;
F2 = 0;
for i = 1:495
	F1 = F1 + (E(1,i))^2;
	F2 = F2 + abs(E(2,i))^2;
end

G1 = sqrt((F1+F2)/495);
G2 = sqrt(F2/495);
