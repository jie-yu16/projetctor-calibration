%clear;clc;

fid1 = fopen('./compute_reproject_pro_corner1.txt');
fid2 = fopen('./compute_reproject_pro_corner2.txt');

Corner_num = 99;

sizeA = [2 Inf];
sizeB = [2 Inf];

A = fscanf(fid1, '%f%f', sizeA);

B = fscanf(fid2, '%f%f', sizeB);

E = A - B;



AA = size(E);

N = AA(2) / Corner_num;

figure;
for i = 1:N 
    
    %scatter(E(1,(i-1)*Corner_num + 1: i*Corner_num), E(2,(i-1)*Corner_num + 1: i*Corner_num), 10, '+');
    plot(E(1,(i-1)*Corner_num + 1: i*Corner_num), E(2,(i-1)*Corner_num + 1: i*Corner_num), '+');
    hold on;
    
end



xlabel('\Deltav');
ylabel('\Deltau');
title('Reprojection error / pixel');

% set(gca, 'XTick', -1:0.5:1);
% set(gca, 'YTick', -1:0.5:1);
% axis([-1 1 -1 1]);

set(gca, 'XTick', -0.3:0.1:0.3);
set(gca, 'YTick', -0.3:0.1:0.3);
axis([-0.3 0.3 -0.3 0.3]);

A1 = max(E(1,:));
A2 = max(E(2,:));

% F1 = 0;
% F2 = 0;
% for i = 1:450
% 	F1 = F1 + (E(1,i))^2;
% 	F2 = F2 + abs(E(2,i))^2;
% end
% 
% G1 = sqrt((F1+F2)/450);
% G2 = sqrt(F2/450);
